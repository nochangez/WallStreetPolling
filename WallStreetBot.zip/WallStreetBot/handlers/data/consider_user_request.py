from aiogram import Dispatcher, types

from data.config import bot, chat_link
from services.telegram.user import User


async def accept_user_request(callback_query: types.CallbackQuery):
    """This function accepts user request to learning and sends him alert about accepting"""

    message = callback_query.message
    requester_id = int(callback_query.data.replace("accept_user_", ''))

    user_accepted_message = ("💼 Мы готовы принять тебя на обучение! 📚\n\n"
                             f"📁 Ссылка на чат с учениками – <b><a href=\"{chat_link}\">тык</a></b>\n\n"
                             "⚡ ️Удачного обучения 🌪")

    user_hyper_link = User().create_user_hyper_link(user_id=requester_id, username=str(requester_id))

    try:
        await bot.send_message(requester_id, text=user_accepted_message)
        await message.edit_text(f"✅ <b>Заявка для {user_hyper_link} принята!</b>")
    except Exception as accepting_error:
        await message.edit_text(f"<b>Пользователь не был принят:</b>\n\n{accepting_error}")


async def decline_user_request(callback_query: types.CallbackQuery):
    """This function declines user request to learning and sends him alert about declining"""

    message = callback_query.message
    requester_id = int(callback_query.data.replace("decline_user_", ''))

    user_declined_message = ("❌ К сожалению, мы пока что не можем принять тебя на обучение 📖\n\n"
                             "⭐ <code>Причину можно узнать у</code> @ws_vbiv")

    user_hyper_link = User().create_user_hyper_link(user_id=requester_id, username=str(requester_id))

    try:
        await bot.send_message(requester_id, text=user_declined_message)
        await message.edit_text(f"❌ <b>Заявка для {user_hyper_link} отменена!</b>")
    except Exception as accepting_error:
        await message.edit_text(f"<b>Ошибка отклонения запроса:</b>\n\n{accepting_error}")


def register_handlers_consider_user_request(dp: Dispatcher):
    dp.register_callback_query_handler(accept_user_request, lambda cb: cb.data and cb.data.startswith("accept"))
    dp.register_callback_query_handler(decline_user_request, lambda cb: cb.data and cb.data.startswith("decline"))
