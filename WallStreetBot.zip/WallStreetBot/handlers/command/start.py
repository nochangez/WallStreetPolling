from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import StatesGroup, State

from data.config import redis_helper, admins, bot
from services.telegram.user import User


class GetAnswersState(StatesGroup):
    """This class is the state that gets user answers"""

    waiting_for_first_answer = State()
    waiting_for_second_answer = State()
    waiting_for_third_answer = State()


async def process_start_command(message: types.Message, state: FSMContext):
    """This function answers to /start command"""

    # finish all active states
    await state.finish()

    await message.answer("Чтобы подать заявку, ответь на три коротких вопроса!")


async def ask_first_question(message: types.Message, state: FSMContext):
    """This function is the first question asking start point"""

    # finish all active states
    await state.finish()

    await message.answer("Чтобы подать заявку, ответь на три коротких вопроса!")

    await message.answer("<b>1)</b> Был ли ты связан со сферой кардинга?")
    await GetAnswersState.waiting_for_first_answer.set()


async def ask_second_question(message: types.Message):
    """This function is the second question asking start point"""

    # write answer to first question in redis
    await redis_helper.redis_set("first_question_answer", message.text)

    await message.answer("<b>2)</b> C какого устройства ты хочешь работать?")
    await GetAnswersState.next()


async def ask_third_question(message: types.Message):
    """This function is the third question asking start point"""

    # write answer to second question in redis
    await redis_helper.redis_set("second_question_answer", message.text)

    await message.answer("<b>3)</b> Есть ли у тебя материал для работы?")
    await GetAnswersState.next()


async def save_polling_results(message: types.Message, state: FSMContext):
    """This function collects question answers to send them to admins"""

    # write answer to third question in redis
    await redis_helper.redis_set("third_question_answer", message.text)

    first_question_answer = str(await redis_helper.decode_bytes(await redis_helper.redis_get("first_question_answer")))
    second_question_answer = str(await redis_helper.decode_bytes(await redis_helper.redis_get(
        "second_question_answer")))
    third_question_answer = message.text

    user_form = User.build_user_form(first_question_answer=first_question_answer,
                                     second_question_answer=second_question_answer,
                                     third_question_answer=third_question_answer,
                                     user_id=message.from_user.id, username=message.from_user.first_name)

    accept_keyboard = types.InlineKeyboardMarkup()

    accept_button = types.InlineKeyboardButton("Принять", callback_data=f"accept_user_{message.from_user.id}")
    decline_button = types.InlineKeyboardButton("Отклонить", callback_data=f"decline_user_{message.from_user.id}")

    accept_keyboard.add(accept_button, decline_button)

    await message.answer(f"✅ <b>{message.from_user.first_name}</b>, твой отчет успешно сформирован и отправлен "
                         f"администраторам!\n\nРезультат рассмотрения автоматически придет сюда, ожидай 😉")

    for admin in admins:
        try:
            await bot.send_message(int(admin), text=user_form, reply_markup=accept_keyboard)
        except:
            continue

    await state.finish()


def register_handlers_start(dp: Dispatcher):
    dp.register_message_handler(ask_first_question, commands=['start'], state=None)
    dp.register_message_handler(ask_second_question, content_types=['text'],
                                state=GetAnswersState.waiting_for_first_answer)
    dp.register_message_handler(ask_third_question, content_types=['text'],
                                state=GetAnswersState.waiting_for_second_answer)
    dp.register_message_handler(save_polling_results, content_types=['text'],
                                state=GetAnswersState.waiting_for_third_answer)
