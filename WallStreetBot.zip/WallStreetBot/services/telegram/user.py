class User:
    """This class exists for working/creating help stuff connected with user"""

    @staticmethod
    def create_user_hyper_link(user_id: int, username: str):
        """This method creates hyperlink with user's name as clickable string"""

        return f"<a href=\"tg://user?id={user_id}\">{username}</a>"

    @staticmethod
    def build_user_form(first_question_answer: str,
                        second_question_answer: str,
                        third_question_answer: str,
                        user_id: int, username: str):
        """This method builds user form with his data (answers to questions and his link)"""

        return ("📥 <b>Новая заявка на обучение:</b>\n\n"
                "<b>Ответы на вопросы:</b>\n"
                f"<b>1.</b> {first_question_answer}\n"
                f"<b>2.</b> {second_question_answer}\n"
                f"<b>3.</b> {third_question_answer}\n\n"
                f"<b>Ученик:</b> {User().create_user_hyper_link(user_id=user_id, username=username)}")
