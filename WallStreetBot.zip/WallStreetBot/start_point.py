import logging
from threading import Thread

from aiogram import executor

from data.config import dispatcher
from handlers.command.start import register_handlers_start
from handlers.data.consider_user_request import register_handlers_consider_user_request


logging.basicConfig(level=logging.DEBUG)


# command handlers
Thread(target=register_handlers_start, args=(dispatcher, )).start()

# data handlers
Thread(target=register_handlers_consider_user_request, args=(dispatcher, )).start()


if __name__ == "__main__":
    executor.start_polling(dispatcher, skip_updates=True)
