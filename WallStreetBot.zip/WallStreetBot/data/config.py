import os

from aiogram import Bot, Dispatcher, types

from data.services.redis_helper import RedisHelper


# PROJECT VARIABLES
tokens = {
    "telegram": os.getenv("telegram"),
}  # tokens

admins = (650387714, 387869905, 5393265384)  # bot admins

chat_link = "https://t.me/+SZzGeE7NZlowMTgy"  # link to chat with pupils


# CALLABLE
redis_helper = RedisHelper()
bot = Bot(token=tokens['telegram'], parse_mode=types.ParseMode.HTML)  # bot object
dispatcher = Dispatcher(bot, storage=redis_helper.redis_storage)  # dispatcher object
